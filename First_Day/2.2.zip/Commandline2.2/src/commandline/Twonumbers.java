package commandline;

import java.util.Scanner;

public class Twonumbers {
public static void main(String[] args) 
{ 
	
	int count = 15; 
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter the num1:");
	int num1=sc.nextInt();
	
	System.out.println("Enter the num2:");
	int num2=sc.nextInt();
	
	System.out.println("Number1 and Number2 is "+num1+" "+ num2);
	System.out.print("The Sequence of next 13 numbers is "); 
	
	for (int i = 1; i <= count; ++i)
	{ 
	
		System.out.print(num1+" ");  
		int sumOfPrevTwo = num1 + num2; 
		num1 = num2; 
		num2 = sumOfPrevTwo;
	
	}
	} 
}

