package instrument;

public abstract class Instrument {
	public abstract void play();
}

